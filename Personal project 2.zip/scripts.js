// scripts.js

document.addEventListener("DOMContentLoaded", function () {
    // 로그인 버튼 이벤트 리스너
    document.querySelector("#loginButton").addEventListener("click", function () {
        // 모달 창 표시
        $("#loginModal").modal("show");
    });
});

// 글쓰기 버튼 이벤트 리스너
document.addEventListener("DOMContentLoaded", function () {
    document.querySelector("#writeButton").addEventListener("click", function () {
        // 글쓰기 페이지로 이동
        window.location.href = "write.html"; // 글쓰기 페이지의 URL을 여기에 입력
    });
});


document.addEventListener("DOMContentLoaded", function () {
    const loginBtn = document.getElementById('loginBtn');
    const logoutBtn = document.getElementById('logoutBtn');
    const followBtn = document.getElementById('followBtn');
    const unfollowBtn = document.getElementById('unfollowBtn');
    const writeBtn = document.getElementById('writeBtn');
    const registerBtn = document.getElementById('registerBtn');
    const deleteBtn = document.getElementById('deleteBtn');
    const editBtn = document.getElementById('editBtn');

    loginBtn.addEventListener('click', function () {
        // 로그인 처리
        alert('로그인되었습니다.');
        loginBtn.style.display = 'none';
        logoutBtn.style.display = 'inline-block';
        followBtn.style.display = 'inline-block';
        writeBtn.style.display = 'inline-block';
    });

    logoutBtn.addEventListener('click', function () {
        // 로그아웃 처리
        alert('로그아웃되었습니다.');
        logoutBtn.style.display = 'none';
        loginBtn.style.display = 'inline-block';
        followBtn.style.display = 'none';
        unfollowBtn.style.display = 'none';
        writeBtn.style.display = 'none';
        registerBtn.style.display = 'none';
        deleteBtn.style.display = 'none';
        editBtn.style.display = 'none';
    });

    followBtn.addEventListener('click', function () {
        // 팔로우 처리
        alert('팔로우되었습니다.');
        followBtn.style.display = 'none';
        unfollowBtn.style.display = 'inline-block';
    });

    unfollowBtn.addEventListener('click', function () {
        // 언팔로우 처리
        alert('언팔로우되었습니다.');
        unfollowBtn.style.display = 'none';
        followBtn.style.display = 'inline-block';
    });

    writeBtn.addEventListener('click', function () {
        // 글쓰기 처리
        alert('글을 작성합니다.');
        writeBtn.style.display = 'none';
        registerBtn.style.display = 'inline-block';
    });

    registerBtn.addEventListener('click', function () {
        // 글등록 처리
        alert('글이 등록되었습니다.');
        registerBtn.style.display = 'none';
        deleteBtn.style.display = 'inline-block';
        editBtn.style.display = 'inline-block';
    });

    deleteBtn.addEventListener('click', function () {
        // 글삭제 처리
        alert('글이 삭제되었습니다.');
        deleteBtn.style.display = 'none';
    });

    editBtn.addEventListener('click', function () {
        // 글수정 처리
        alert('글을 수정합니다.');
    });
});

